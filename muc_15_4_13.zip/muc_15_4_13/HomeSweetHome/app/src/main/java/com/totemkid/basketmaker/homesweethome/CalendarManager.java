package com.totemkid.basketmaker.homesweethome;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.format.DateUtils;
import android.util.Log;
import android.util.Pair;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by basketmaker on 21/06/15.
 */
public class CalendarManager {
    private static final String TAG = "the calendar ";

    Map<String,Pair<Long,Long>> listEvent;


    /*
     * The constructor we query the calendar manager
     * and construct a hashmap of paired object
     * the key is the title of event and the pair is
     * the begin and the end timestamp
     */

    public CalendarManager(Context context)
    {

        /*
        * The following code in comment is usefull to get all the ids of the agenda
        * */


        /*
        ContentResolver contentResolver = context.getContentResolver();

        final Cursor cursor = contentResolver.query(Uri.parse("content://com.android.calendar/calendars"),
                (new String[] { "_id" }), null, null, null);

        while (cursor.moveToNext()) {

            final String _id = cursor.getString(0);

            System.out.println("Id: " + _id );
        }

        */
        Calendar beginTime = Calendar.getInstance();
        beginTime.set(2015, 5, 23, 8, 0);
        long startMillis = beginTime.getTimeInMillis();
        Calendar endTime = Calendar.getInstance();
        endTime.set(2015, 5, 29, 8, 0);
        long endMillis = endTime.getTimeInMillis();




        Uri.Builder builder = Uri.parse("content://com.android.calendar/instances/when/").buildUpon();
        long now = new Date().getTime();
        ContentUris.appendId(builder, now - DateUtils.DAY_IN_MILLIS);
        ContentUris.appendId(builder, now + DateUtils.DAY_IN_MILLIS);


        Cursor eventCursor = context.getContentResolver().query(builder.build(),
                new String[]{"title", "begin", "end", "calendar_id"}, "calendar_id=5",
                null, "startDay ASC, startMinute ASC");
        listEvent = new HashMap<>();
        while (eventCursor.moveToNext()) {
            final String title = eventCursor.getString(0);
            final long begin = eventCursor.getLong(1);
            final long end = eventCursor.getLong(2);
            listEvent.put(title,new Pair<Long, Long>(begin,end));
        }
        for(String event : listEvent.keySet())
            Log.d(TAG, event);
    }
    /*
    * Return if a course is standing now
    * */

    public boolean isAcourseRunningNow()
    {
        long now = new Date().getTime();
        boolean isCourse = false;
        for(String titles : listEvent.keySet())
        {
            long timeBegin = listEvent.get(titles).first;
            long timeEnd = listEvent.get(titles).second;
            if(timeBegin<now && now<timeEnd)
                isCourse=true;
        }
        return isCourse;
    }

    /*
     * return if there is a course in 30 minutes
     */

    public boolean isCourseIn30Min()
    {
        long nowPlus30 = new Date().getTime()+(DateUtils.HOUR_IN_MILLIS/2);
        boolean isCourse30 = false;
        for(String titles : listEvent.keySet())
        {
            long timeBegin = listEvent.get(titles).first;
            long timeEnd = listEvent.get(titles).second;
            if(timeBegin<nowPlus30 && nowPlus30<timeEnd)
                isCourse30=true;
        }
        return isCourse30;
    }


    /*
    * Return if it is the first course of the day
    * didn't work patch it later
    * */
    public boolean isFirstCourseIn30Mn()
    {
        long nowPlus30 = new Date().getTime()+(DateUtils.HOUR_IN_MILLIS/2);
        boolean isFirstCourse30 = true;
        for(String titles : listEvent.keySet())
        {

            long timeBegin = listEvent.get(titles).first;
            Date datenowPlus30 = new Date(nowPlus30);
            Date dateCour = new Date(timeBegin);
            long timeEnd = listEvent.get(titles).second;
            if(datenowPlus30.getDay() == dateCour.getDay() )
                if(!(timeBegin<nowPlus30 && nowPlus30<timeEnd))
                    if(datenowPlus30.getHours() > dateCour.getHours())
                        isFirstCourse30=false;
        }
        return true;
    }
}
