package com.totemkid.basketmaker.homesweethome;

import android.app.IntentService;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.text.format.DateUtils;
import android.util.Log;
import android.widget.Toast;


/*
 * The service who run in background
 */


public class ContextAwareService extends IntentService {
    public String TAG = "call from service";
    private PressureSensor pressureSensor;
    private LightSensor lightSensor;
    private HomeDetectionManager homeManager;
    private SensorManager sensorManager;
    private Sensor sensorpressure;
    private Sensor sensorlight;
    private CalendarManager calendar;
    private String wifiNearHome;
    private String bluetoothNearHome;

    private TurnOnTheLight turnOnTheLight;
    private Meteo meteo;
    private DisplayBusStation displayBusStation;


    public ContextAwareService() {
        super("ContextAwareService");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();


        /*
         * Home Sensor detector
         * there are wifi and bluetooth
         *
         */

        homeManager = new HomeDetectionManager(getApplicationContext());
        IntentFilter filterWifi = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(homeManager.getWifiReceiver(), filterWifi);
        IntentFilter filterBluetooth = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(homeManager.getBluetoothReceiver(), filterBluetooth);

        //get the wifi near your home
        wifiNearHome = intent.getStringExtra("WifiNearHome");
        homeManager.setWifiHome(wifiNearHome);
        //get the bluetooth near your home
        bluetoothNearHome = intent.getStringExtra("BluetoothNearHome");
        homeManager.setBluetoothHome(bluetoothNearHome);


        /*
         * Sensor event
         * those who acquired the meteo and luminosity
         */

        pressureSensor = new PressureSensor();
        lightSensor = new LightSensor();

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorpressure = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);
        sensorManager.registerListener(pressureSensor, sensorpressure, SensorManager.SENSOR_DELAY_NORMAL);


        sensorlight = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        sensorManager.registerListener(lightSensor, sensorlight, SensorManager.SENSOR_DELAY_NORMAL);

        /*
         * Get the calendar event
         */

        calendar = new CalendarManager(getApplicationContext());



        /*
        * The 3 Threads who run independently
        * in order to detect the three situation
        * the componet which acquired the data are not in the threads
        * the threads only reads the data on the component
        * to avoid them to block themselves
        * */
        meteo = new Meteo();
        turnOnTheLight = new TurnOnTheLight();
        displayBusStation = new DisplayBusStation();



        return super.onStartCommand(intent,flags,startId);


    }





    @Override
    protected void onHandleIntent(Intent intent) {

        PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK , "My Tag");

        wl.acquire();
        Log.d(TAG, "service started");


        displayBusStation.start();
        meteo.start();
        turnOnTheLight.start();

        while (true) {

        }
    }

    /*
     * Display the meteo
     */

    public void sendWeatherNotification(String arg)
    {
        int icon = R.drawable.sun;
        Notification notif = new Notification(icon,"weather is bad",System.currentTimeMillis());
        notif.defaults = Notification.DEFAULT_ALL;
        //create "pending intent" to start activity
        //when notifiation is selected
        Intent notifIntent = new Intent(this, HomeSweetHome.class);
        notifIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pendIntent = PendingIntent.getActivity(this, 0,notifIntent, 0);
        //add notification infos for panel view and add pending intent
        //get Notification Manager

        notif.setLatestEventInfo(this, "The weather is", arg, pendIntent);
        NotificationManager mNMgr  = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        //add notification
        mNMgr.notify(0, notif);
        startForeground(0, notif);
    }



    /*
     * Display light notification
     * We didn t manage to work the light manager
     */

    public void sendLightNotification()
    {
        int icon = R.drawable.sun;
        Notification notif = new Notification(icon,"SomeOne turn 0f th3 Light",System.currentTimeMillis());
        notif.defaults = Notification.DEFAULT_ALL;
        //create "pending intent" to start activity
        //when notifiation is selected
        Intent notifIntent = new Intent(this, HomeSweetHome.class);
        notifIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        PendingIntent pendIntent = PendingIntent.getActivity(this, 0,notifIntent, 0);
        //add notification infos for panel view and add pending intent
        //get Notification Manager

        notif.setLatestEventInfo(this, "You better", "turn your light on (we didn t manage it in our Nexus with Lollipop)", pendIntent);
        NotificationManager mNMgr  = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        //add notification
        mNMgr.notify(0, notif);
        startForeground(0, notif);
    }


    /*
     * get pressure of the moment
     *
     */
    private class PressureSensor implements SensorEventListener
    {
        private float pressure;
        public PressureSensor()
        {
            /*
             * for the first mesure we need a 0
             *
             */
        }
        public float getPressure()
        {
            return pressure;
        }

        @Override
        public void onSensorChanged(SensorEvent event) {

            pressure = event.values[0];
            /*
             * For Ulm altitude 400 m
             * 100 m is almost 8.6 hPa
             */
            pressure += 8.6*4;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }

    private class LightSensor implements SensorEventListener
    {
        private float light;
        public LightSensor()
        {
        }

        public float getLuminosity()
        {
            return light;
        }

        @Override
        public void onSensorChanged(SensorEvent event) {
            light = event.values[0];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    }

    /*
    *  This thread is in charge of the meteo
    *  Take one mesure per hour
    *  check the agenda if the user go elsewhere if
    *  also check if user is at home only if he is at home
    * */
    class Meteo extends Thread
    {
        private float value[] = new float[24];
        private int next = 0;
        private long precTime = 0;
        @Override
        public void run() {
            Log.d(TAG,"we go far to this point meteo");

            while(!isInterrupted())
            {
                /*Acquire data*/
                if(System.currentTimeMillis()-precTime > DateUtils.HOUR_IN_MILLIS)
                {
                    value[next%24] = pressureSensor.getPressure();
                    next++;
                    precTime = System.currentTimeMillis();
                }
                if(calendar.isCourseIn30Min())
                {
                   if(calendar.isFirstCourseIn30Mn())
                        if(homeManager.isAtHome())
                        {
                            sendHimTheWeather();
                            try {
                                Thread.sleep(DateUtils.HOUR_IN_MILLIS);
                            }
                            catch(Exception e){}
                        }
                }
            }
        }
        /*
        * Now we gonna detect if there is good or bad weather
        * */
        public void sendHimTheWeather()
        {
            int i = next;
            if(i-2 >= 0)
            {
                if((value[(i-1)%24] - value[(i-2)%24]) > 0 && value[(i-1)%24] >= 1020)
                    sendWeatherNotification("It s gonna be sunny for sometime");
                if((value[(i-1)%24] - value[(i-2)%24]) < -3 && value[(i-1)%24] >= 1000)
                    sendWeatherNotification("Bad Weather");
                if((value[(i-1)%24] - value[(i-2)%24]) < 2 && value[(i-1)%24] < 1015)
                    sendWeatherNotification("You should be aware take you re coat");

            }
        }
    }

    /*
     * This thread Display the bus stations if we have a course in 30 minutes and we are at home
     */

    class DisplayBusStation extends Thread
    {
        long precTime = 0;
        @Override
        public void run() {
            Log.d(TAG, "we go far to this point bus");
            while(!isInterrupted()) {
                if (System.currentTimeMillis() - precTime > 20000) {
                    if (calendar.isCourseIn30Min())
                    {
                        if (calendar.isFirstCourseIn30Mn())
                            if (homeManager.isAtHome()) {
                                Intent dialogIntent = new Intent(ContextAwareService.this, DisplayBus.class);
                                dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(dialogIntent);
                                try {
                                    Thread.sleep(DateUtils.HOUR_IN_MILLIS * 2);
                                } catch (Exception e) {
                                }
                            }
                    }
                    precTime = System.currentTimeMillis();
                }
            }
        }

    }

    /*
     * This thread will decide if we turn the light on
     */

    class TurnOnTheLight extends Thread
    {
        long precTime=0;
        @Override
        public void run () {
            Log.d(TAG, "we go far to this point light");
            while(!isInterrupted()) {
                if(System.currentTimeMillis() - precTime > 10000) {
                    KeyguardManager myKM = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                    if (myKM.inKeyguardRestrictedInputMode()) {
                    } else {
                        if(lightSensor.getLuminosity() == 0)
                            if(!calendar.isAcourseRunningNow())
                                sendLightNotification();
                    }
                    precTime = System.currentTimeMillis();
                }
            }
        }

    }




    @Override
    public void onDestroy() {
        meteo.interrupt();
        turnOnTheLight.interrupt();
        displayBusStation.interrupt();
        unregisterReceiver(homeManager.getWifiReceiver());
        unregisterReceiver(homeManager.getBluetoothReceiver());
        sensorManager.unregisterListener(pressureSensor);
        sensorManager.unregisterListener(lightSensor);
        super.onDestroy();
    }
}
