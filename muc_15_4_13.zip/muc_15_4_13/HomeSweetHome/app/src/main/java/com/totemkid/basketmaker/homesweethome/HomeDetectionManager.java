package com.totemkid.basketmaker.homesweethome;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.util.Log;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by basketmaker on 20/06/15.
 * You can detect wifi around and their power
 * usefull for having your position if you don t have access to you're location manager
 */
public class HomeDetectionManager {

    private String TAG = "HomeDetectionManager";

    private WifiManager wifiManager;
    private BroadcastReceiver wifiReceiver;
    private List<WifiAccessPoint> wifiProximity;
    private List<BlueToothDevices> blueToothDevicesList;
    private List<WifiAccessPoint> wifiProximityHome = null;
    private List<BlueToothDevices> blueToothDevicesListHome = null;
    private BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    private BroadcastReceiver bluetoothReceiver;

    HomeDetectionManager(Context context)
    {
        /*
        *Bluetooth
        **/

        blueToothDevicesList = new ArrayList<>();

        mBluetoothAdapter.startDiscovery();
        bluetoothReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    boolean contains = false;
                    for (BlueToothDevices c : blueToothDevicesList)
                        if(c.getAdresse().equals(device.getAddress()))
                            contains = true;
                    if(!contains)
                        blueToothDevicesList.add(new BlueToothDevices(device.getAddress(),device.getName()));
                }
            }
        };



        /*
        * WIFI
        **/


        wifiProximity = new ArrayList();

        wifiManager = (WifiManager)context.getSystemService(Context.WIFI_SERVICE);
        if(!wifiManager.isWifiEnabled())
        {
            Log.d(TAG,"Wifi isn t enabled");
        }
        else
        {
            Log.d(TAG,"Wifi is enabled start aquire now");
        }
        wifiManager.startScan();
        wifiReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                if (wifiManager != null) {
                    wifiProximity = new ArrayList<>();
                    if (wifiManager.isWifiEnabled()) {
                        for (ScanResult scan : wifiManager.getScanResults()) {
                            boolean contains = false;
                            for(WifiAccessPoint c : wifiProximity)
                                if(c.getHotspot().equals(scan.BSSID))
                                    contains = true;
                            if(!contains)
                                wifiProximity.add(new WifiAccessPoint(scan.SSID, scan.BSSID, scan.level));
                        }
                        Collections.sort(wifiProximity);
                    }
                }
            }
        };

    }

    public BroadcastReceiver getWifiReceiver()
    {
        return wifiReceiver;
    }
    public BroadcastReceiver getBluetoothReceiver()
    {
        return bluetoothReceiver;
    }

    public void setWifiHome(String wifiJson)
    {
        wifiProximityHome = new ArrayList<>();
        try {
            JSONArray liste = new JSONArray(wifiJson);
            if(liste != null)
            {
                int i;
                for(i = 0 ; i < liste.length(); i++)
                {
                    wifiProximityHome.add(new WifiAccessPoint(
                            liste.getJSONObject(i).getString("name"),
                            liste.getJSONObject(i).getString("hotspot"),
                            liste.getJSONObject(i).getInt("level")
                    ));
                }
            }
        }
        catch (Exception e)
        {
            Log.d(TAG,"unreadable JSON");
            return ;
        }

    }

    public void setBluetoothHome(String BluetoothJson)
    {
        blueToothDevicesListHome = new ArrayList<>();
        try {
            JSONArray liste = new JSONArray(BluetoothJson);
            if(liste != null)
            {
                int i;
                for(i = 0 ; i < liste.length(); i++)
                {
                    blueToothDevicesListHome.add(new BlueToothDevices(
                            liste.getJSONObject(i).getString("adresse"),
                            liste.getJSONObject(i).getString("name")
                    ));
                }
            }
        }
        catch (Exception e)
        {
            Log.d(TAG,"unreadable JSON");
            return ;
        }
    }

    private int getSimilarity() {


        int numberOfSimilarities = 0;
        List<String> adresses = new ArrayList<>();
        List<String> adressesHome = new ArrayList<>();
        for(WifiAccessPoint c : wifiProximity)
            adresses.add(c.getHotspot());
        for(WifiAccessPoint c : wifiProximityHome)
            adressesHome.add(c.getHotspot());
        for(BlueToothDevices c : blueToothDevicesList)
            adresses.add(c.getAdresse());
        for(BlueToothDevices c : blueToothDevicesListHome)
            adressesHome.add(c.getAdresse());

        /* Now we get the number of similarity between the two list*/

        for(String home : adressesHome)
        {
            for(String now : adresses)
                if(now.equals(home))
                    numberOfSimilarities++;
        }

        /* And now we compute the percent of similarities */

        return (int)(((float)(adressesHome.size() - numberOfSimilarities)/(float)adressesHome.size())*100);
    }

    public boolean isAtHome()
    {
        if(getSimilarity() >= 30)
            return true;
        return false;
    }

    public String getJSONRepresentationOfWIFI()
    {
        String tmp = "[";

        for(WifiAccessPoint c : wifiProximity)
        {
            tmp+=c.getJSONRepresentation()+",";
        }
        tmp = tmp.substring(0,tmp.length()-1);
        if(tmp.length() != 1)
            tmp+="]";
        return tmp;
    }
    public String getJSONRepresentationOfBlueTooth()
    {
        String tmp = "[";

        for(BlueToothDevices c : blueToothDevicesList)
        {
            tmp+=c.getJSONRepresentation()+",";
        }
        if(tmp.length() != 1)
            tmp = tmp.substring(0,tmp.length()-1);
        tmp+="]";
        return tmp;

    }

    private class WifiAccessPoint implements Comparable<WifiAccessPoint>
    {
        private int level;
        private String name;
        private String hotspot;

        public WifiAccessPoint(String pssid, String pbssid, int plevel)
        {
            hotspot = pbssid;
            name = pssid;
            level = plevel;
        }

        @Override
        public int compareTo(WifiAccessPoint another) {
            WifiAccessPoint other = another;
            return other.level - this.level;
        }

        public String getJSONRepresentation()
        {
            return    "{\"level\" : \""+level+"\","+
                      " \"name\" : \""+name+"\","+
                      " \"hotspot\" : \""+hotspot+"\" }";
        }

        public int getLevel()
        {
            return level;
        }

        public String getName()
        {
            return name;
        }
        public String getHotspot()
        {
            return hotspot;
        }
        public String toString()
        {
            return "\"level\" : \""+level+"\","+
                    " \"name\" : \""+name+"\","+
                    " \"hotspot\" : \""+hotspot+"\" ";
        }
    }

    private class BlueToothDevices
    {
        private String name;
        private String adresse;

        public BlueToothDevices(String padresse,String pname) {

            name = pname;
            adresse = padresse;

        }
        public String getAdresse()
        {
            return adresse;
        }
        public String getJSONRepresentation()
        {
            return "{ \"name\" : \""+name+"\","+
                      "\"adresse\" : \""+adresse+"\"}";
        }
    }
}
