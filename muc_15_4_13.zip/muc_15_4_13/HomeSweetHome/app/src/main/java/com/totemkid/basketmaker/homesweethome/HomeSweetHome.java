package com.totemkid.basketmaker.homesweethome;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;


/*
* On this activity we set the home environnement and we start the service
* */


public class HomeSweetHome extends ActionBarActivity {
    private String TAG = "Home Sweet Home main app";
    private HomeDetectionManager home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_sweet_home);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_home_sweet_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void startService(View v)
    {
        Intent intent = new Intent(getApplicationContext(), ContextAwareService.class );
        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        intent.putExtra("WifiNearHome",sharedPref.getString("HomeWifi","no wifi available"));
        intent.putExtra("BluetoothNearHome",sharedPref.getString("HomeBluetooth","no bluetooth available"));
        startService(intent);
    }
    public void setUpService(View v)
    {
        home = new HomeDetectionManager(getApplicationContext());
        IntentFilter filterWifi = new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(home.getWifiReceiver(), filterWifi);
        IntentFilter filterBluetooth = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(home.getBluetoothReceiver(), filterBluetooth);
        HomeThread homeThread = new HomeThread();
        homeThread.execute();
    }
    public void stopService(View v)
    {
        stopService(new Intent(this, ContextAwareService.class));
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_SHORT).show();
    }





    /*
    * This asyncTask is for save data in the sharedpref
    * the datas are the wifi and bluetooth that we detect
    * when we make the discovery
    * */
    private class HomeThread extends AsyncTask<Void,Void,Void>
    {

        /* Wait while the wifis are detected */
        @Override
        protected Void doInBackground(Void... params) {
            long endTime = System.currentTimeMillis() + 10*1000;
            while (System.currentTimeMillis() < endTime) {
                synchronized (this) {
                    try {
                        wait(endTime - System.currentTimeMillis());
                    } catch (Exception e) {
                        Log.d(TAG, "there is a problem sir");
                    }
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result)
        {

            SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("HomeWifi",home.getJSONRepresentationOfWIFI());
            editor.putString("HomeBluetooth",home.getJSONRepresentationOfBlueTooth());
            editor.commit();
            Toast.makeText(HomeSweetHome.this, "data acquired", Toast.LENGTH_SHORT).show();
            unregisterReceiver(home.getWifiReceiver());
            unregisterReceiver(home.getBluetoothReceiver());
        }
    }
}
